package com.example.sem2_dz2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sem2Dz2Application {

	public static void main(String[] args) {
		SpringApplication.run(Sem2Dz2Application.class, args);
	}

}
