package com.example.sem2_dz2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sem2Dz2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
